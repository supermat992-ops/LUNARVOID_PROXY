LUNARVOID PROXY — WINDOWS PC APP
Version 0.6.3-experimental

1. Right-click the ZIP and choose Extract All.
2. Open the extracted LUNARVOID-PC folder.
3. Double-click LUNARVOID.exe.

Requires 64-bit Windows 10/11 and Microsoft Edge (or Google Chrome).
Python is bundled; no separate Python installation or admin setup is needed.
Keep the included folders beside LUNARVOID.exe. You can create a desktop
shortcut to the executable. The executable is an unsigned preview build.

The app opens the website interface in its own browser app window and starts
its own local UDP relay automatically. Add/select a Bedrock server, press
Start Proxy, then join the displayed 127.0.0.1 address and port in Minecraft
on this PC. Keep the app open or minimized while playing. Exit PC app stops
its local relay and closes its dedicated browser process.

This package's connection mode is same-PC only. It does not include the
Android LAN discovery mode or expose a public IP. The existing web relay's
10-minute idle/8-hour lifetime limits apply. It does not change Minecraft
version compatibility. Real Minecraft gameplay has not been verified.

Settings and build/skin uploads are saved in a separate browser profile at
%LOCALAPPDATA%\LunarVoidProxy\BrowserProfile. They do not automatically sync
with your normal browser or Android app. The stable local app port is45321;
if that port is occupied, close the previous app before opening it again.

The interface, local previews and existing limits match the website.
In-game modules, emote menu activation and replay recording are still
unavailable. This package does not turn those previews into working mods.

Windows launch and browser-process behavior still need testing on a real PC.
Local host/UDP/lifecycle tests and archive checks were performed in Linux.

Python runtime: official Python3.14.4 Windows embeddable distribution.
Its license is included in runtime/LICENSE.txt. The Chromium browser is
provided by your installed Edge/Chrome, not bundled in this package.

EXPERIMENTAL GAME MODE
In Play, use the separate game mode panel. Sign in with the same Microsoft
account as Minecraft, select a Bedrock26.30/26.50 server and Start game proxy.
Join its displayed address, then play an emote (opening the wheel is not enough).
The engine sends a Minecraft form menu. No gameplay modules/custom HUD/replays.
Real-device gameplay remains unverified. Resource-pack servers are not supported.
Sign out/exit stops the engine; credentials are memory-only.
